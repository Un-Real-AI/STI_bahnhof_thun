# Interactive Report Template

This folder is a clean, data-driven shell based on the ZH report UI. Everything loads from `sections.json` plus Markdown/HTML assets.

## Structure
- `index.html` – UI shell (light/dark + large text toggles, markdown renderer, TOC, assets/tabs/PDF panels, image modal)
- `sections.json` – Configure sections, markdown paths, assets, tabs, downloads, help embeds, etc.
- `content/` – Placeholder markdown files (`intro.md`, `demo.md`).
- `assets/` – Sample local iframe (`sample.html`).
- `ttnorms.css` – Font-face + font stack (uses relative `./TTNorms®Pro/...` paths). Fonts are not included by default.

## Use
1) Open `index.html` in a browser (or serve locally).
2) Edit `sections.json` to add/remove sections and assets.
3) Replace markdown in `content/` with your text.
4) Replace or add iframe assets in `assets/` or point to external URLs.

## Optional: add fonts
If you have licensed TT Norms Pro, place the folder at `tempalte/TTNorms®Pro/` matching the paths in `ttnorms.css`. Otherwise the stack falls back to system fonts.

## Zip for sharing
From repo root:
```bash
zip -r tempalte.zip tempalte
```
