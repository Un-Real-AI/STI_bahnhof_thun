# Willkommen

Dies ist ein Platzhalter für dein erstes Kapitel. Ersetze diese Markdown-Datei durch deine Inhalte.

- Nutze normale Markdown-Syntax (Überschriften, Listen, Tabellen, Bilder)
- Bilder werden automatisch mit Zoom-Overlay versehen
- Tabellen bekommen horizontales Scrolling auf kleinen Screens
