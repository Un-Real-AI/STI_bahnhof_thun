# Demo Assets

Dieses Kapitel zeigt, wie Embeds und Tabs funktionieren.

## Karten / Dashboards

Das Asset-Grid unten lädt automatisch das erste Element (Example.com). Passe `assets` im Abschnitt `demo` deiner `sections.json` an.

## Tabs

Die Tab-Navigation lädt Ansichten erst beim Aktivieren (Lazy Loading). Höhe per `height` in `sections.json`.
